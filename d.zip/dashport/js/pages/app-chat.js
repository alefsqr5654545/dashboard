//[app chat Javascript]

//Project:	Crypto Admin - Responsive Admin Template

$(function () {
  'use strict';
	// chat app scrolling
  
	  $('#chat-app').slimScroll({
		height: '600px'
	  });
	
}); // End of use strict
